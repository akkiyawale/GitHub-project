# WakeUp-Capstone-Project
 Design a responsive website for a boutique coffee company named WakeCup.
